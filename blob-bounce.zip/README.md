# Blob Bounce

Jeu minimaliste .io développé en HTML5/Canvas.

Déplacez votre blob dans un univers néon sombre et collectez des blobs et power-ups.

Déploiement rapide possible sur GitHub Pages.